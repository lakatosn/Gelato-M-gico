import mlflow
import mlflow.sklearn
import pandas as pd

RUN_ID = "<COLOQUE_SEU_RUN_ID_AQUI>"

model = mlflow.sklearn.load_model(f"runs:/{RUN_ID}/model")

novas_temperaturas = pd.DataFrame({'temperatura': [26, 29, 34]})
vendas_previstas = model.predict(novas_temperaturas)

for temp, venda in zip(novas_temperaturas['temperatura'], vendas_previstas):
    print(f"Temperatura: {temp}°C -> Vendas previstas: {venda:.1f} sorvetes")
